import './GridStyles.scss';
function GridStyles({ children }) {
    return children;
}

export default GridStyles;
