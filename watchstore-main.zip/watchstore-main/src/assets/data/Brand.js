export const brands = [
    {
        id: 1,
        url: 'https://wscdn.vn/upload/original-image/CS.jpg?size=260x81&fomat=webp',
        desc: 'casio',
    },
    {
        id: 2,
        url: 'https://wscdn.vn/upload/original-image/CS.jpg?size=260x81&fomat=webp',
        desc: 'Orient',
    },
    {
        id: 3,
        url: 'https://wscdn.vn/upload/original-image/CS.jpg?size=260x81&fomat=webp',
        desc: 'Bentley',
    },
    {
        id: 4,
        url: 'https://wscdn.vn/upload/original-image/CS.jpg?size=260x81&fomat=webp',
        desc: 'Citizen',
    },
    {
        id: 5,
        url: 'https://wscdn.vn/upload/original-image/CS.jpg?size=260x81&fomat=webp',
        desc: 'SR',
    },

    {
        id: 6,
        url: 'https://wscdn.vn/upload/original-image/CS.jpg?size=260x81&fomat=webp',
        desc: 'casio',
    },
    {
        id: 7,
        url: 'https://wscdn.vn/upload/original-image/CS.jpg?size=260x81&fomat=webp',
        desc: 'HuBlot',
    },
    {
        id: 8,
        url: 'https://wscdn.vn/upload/original-image/CS.jpg?size=260x81&fomat=webp',
        desc: 'Seiko',
    },
    {
        id: 9,
        url: 'https://wscdn.vn/upload/original-image/CS.jpg?size=260x81&fomat=webp',
        desc: 'Longines',
    },
    {
        id: 10,
        url: 'https://wscdn.vn/upload/original-image/CS.jpg?size=260x81&fomat=webp',
        desc: 'Omega',
    },
    {
        id: 11,
        url: 'https://wscdn.vn/upload/original-image/CS.jpg?size=260x81&fomat=webp',
        desc: 'tissot',
    },
    {
        id: 12,
        url: 'https://wscdn.vn/upload/original-image/CS.jpg?size=260x81&fomat=webp',
        desc: 'G-shock',
    },
];
