const slides = [
    {
        id: 1,
        url: 'https://wscdn.vn/upload/original-image/BANNER-CH%C3%8DNH-5-121392520-1976635005.jpg?size=1920x512&fomat=webp',
        title: 'slide 1',
    },
    {
        id: 2,
        url: 'https://wscdn.vn/upload/original-image/banner-dan-van-phong.jpeg?size=1920x512&fomat=webp',
        title: 'slide 2',
    },
    {
        id: 3,
        url: 'https://shop.30shine.com/_next/image?url=https%3A%2F%2Fstatic.30shine.com%2Fshop-web%2Fbanners%2FbannerT0823-4.jpg&w=1920&q=75',
        title: 'slide 3',
    },
];

export default slides;
