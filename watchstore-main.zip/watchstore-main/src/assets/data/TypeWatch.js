export const typewatchs = [
    {
        id: 1,
        img: 'https://wscdn.vn/upload/original-image/collection-nam.jpeg?size=250x108&fomat=webp',
        title: 'đồng hồ nam',
    },
    {
        id: 2,
        img: 'https://wscdn.vn/upload/original-image/collection-nu.jpeg?size=250x108&fomat=webp',
        title: 'đồng hồ nữ',
    },
    {
        id: 3,
        img: 'https://wscdn.vn/upload/original-image/collection-thuy-sy.jpeg?size=250x108&fomat=webp',
        title: 'đồng hồ thụy sỹ',
    },
    {
        id: 4,
        img: 'https://wscdn.vn/upload/original-image/collection-dien-tu.jpeg?size=250x108&fomat=webp',
        title: 'đồng hồ điện tử',
    },
    {
        id: 5,
        img: 'https://wscdn.vn/upload/original-image/collection-cao-cap.jpeg?size=250x108&fomat=webp',
        title: 'đồng hồ cao cấp',
    },
    {
        id: 6,
        img: 'https://wscdn.vn/upload/original-image/collection-co.jpeg?size=250x108&fomat=webp',
        title: 'đồng hồ cơ',
    },
    {
        id: 7,
        img: 'https://wscdn.vn/upload/original-image/collection-nhat-ban.jpeg?size=250x108&fomat=webp',
        title: 'đồng hồ nhật bản',
    },
    {
        id: 8,
        img: 'https://wscdn.vn/upload/original-image/collection-pin.jpeg?size=250x108&fomat=webp',
        title: 'đồng hồ pin/Quartz',
    },
    {
        id: 9,
        img: 'https://wscdn.vn/upload/original-image/collection-day-kim-loai.jpeg?size=250x108&fomat=webp',
        title: 'đồng hồ dây kim loại',
    },
    {
        id: 10,
        img: 'https://wscdn.vn/upload/original-image/collection-day-da.jpeg?size=250x108&fomat=webp',
        title: 'đồng hồ dây da',
    },
];
