function HomeAdmin() {
    return ( 
        <div>
            <h2>Home Admin</h2>
        </div>
     );
}

export default HomeAdmin;