export { default as DefaultLayout } from './DefaultLayout';
export { default as LayoutHaveSlide } from './LayoutHaveSlide';
